﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Kalkulačka_Projekt
{
    public class DisplayControler : INotifyPropertyChanged
    {
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public event PropertyChangedEventHandler PropertyChanged;

        //konstruktor
        public DisplayControler ()
        {
            calculated = false;
        }

        //bool test

        bool calculated;

        public void calculatedChange()
        {
            calculated = true;
        }

        //Display výpočtu

        string displayCalculation = "";

        public string DisplayCalculation
        {
            get { return displayCalculation; }
            set
            {
                displayCalculation = value;
                OnPropertyChanged();
            }
        }

        public void displayCalculationChange(String x)
        {
            if (calculated)
            {
                calculationClear();
                resultClear();
                calculated = false;
            }
            DisplayCalculation = DisplayCalculation + x;
        }

        public void calculationClear()
        {
            DisplayCalculation = null;
        }

        //display result

        string displayResult = "";

        public string DisplayResult
        {
            get { return displayResult; }
            set
            {
                displayResult = value;
                OnPropertyChanged();
            }
        }

        public void displayResultChange(String x)
        {
            DisplayResult = x;
        }

        public void resultClear()
        {
            DisplayResult = null;
        }

        //delete tlačítko
        public void delete()
        {
            if (calculated == true)
            {
                resultClear();
                calculationClear();
                calculated = false;
            }

            if (DisplayCalculation.Length == 0)
            {
                DisplayCalculation = DisplayCalculation;
            }
            else
            {
                DisplayCalculation = (DisplayCalculation.Remove(DisplayCalculation.Length - 1, 1));
            }
        }
    }

}
